package cs211;

public interface SuperSackSet {

//returns the total number of objects in the set	
	public int sizeOf();

//returns the number of distinct objects in the super sack set 
	public int uniques();

	// returns true if set is empty
	public boolean isEmpty();

//adds an item in the set. If already present, increments count instead.
	public void addElement(Object o);

//decrements the count of a matching object and removes from the list if count is zero
	public void removeElement(Object o);

// returns true if matching item is found (.equals() is true).
	public boolean contains(Object o);

// returns number of matching items in set
	public int occurencesOf(Object o);

// resets to an empty state
	public void clear();

}
