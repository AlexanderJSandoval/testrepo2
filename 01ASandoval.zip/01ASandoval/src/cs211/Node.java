package cs211;

public class Node {

	private Object o;
	private int counter;

	public Node(Object o) {
		this.counter = counter;
		this.o = o;
	}

	public Object getO() {
		return o;
	}

	public void setO(Object o) {
		this.o = o;
	}

	public int getCounter() {
		return counter;
	}

	public void incCounter() {
		counter++;
	}

	public void decCounter() {
		counter--;
	}

}