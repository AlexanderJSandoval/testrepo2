package cs211;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SuperSackSetObjTest {

	@Test
	void testRemove() {
		SuperSackSetObj tester = new SuperSackSetObj();
		String obito = "half";
		String rin = "Through";
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);

		assertEquals(tester.occurencesOf(obito), 5);
		tester.removeElement(obito);
		assertEquals(tester.occurencesOf(obito), 4);
		assertEquals(tester.occurencesOf(rin), 1);
		tester.removeElement(rin);
		assertEquals(tester.occurencesOf(rin), 0);
	}

	@Test
	void testClear() {
		SuperSackSetObj tester = new SuperSackSetObj();
		String obito = "half";
		String rin = "Through";
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(rin);

		assertEquals(tester.isEmpty(), false);
		tester.clear();
		assertEquals(tester.isEmpty(), true);

	}

	@Test
	void testContainsT() {
		SuperSackSetObj tester = new SuperSackSetObj();
		String obito = "half";
		String rin = "Through";
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(rin);

		assertEquals(tester.contains(obito), true);

	}

	@Test
	void testContainsF() {
		SuperSackSetObj tester = new SuperSackSetObj();
		String obito = "half";
		String rin = "Through";
		tester.addElement(rin);
		tester.addElement(rin);
		tester.addElement(rin);

		// System.out.println("The size is:"+tester.sizeOf());

		assertEquals(tester.contains(obito), false);

	}

	@Test
	void testIsEmptyT() {
		SuperSackSetObj tester = new SuperSackSetObj();

		// System.out.println("The size is:"+tester.sizeOf());

		assertEquals(tester.isEmpty(), true);

	}

	@Test
	void testIsEmptyF() {
		SuperSackSetObj tester = new SuperSackSetObj();
		String obito = "half";
		String rin = "Through";

		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(rin);

		// System.out.println("The size is:"+tester.sizeOf());

		assertEquals(tester.isEmpty(), false);

	}

	@Test
	void testUniques() {
		SuperSackSetObj tester = new SuperSackSetObj();
		String obito = "half";
		String rin = "Through";
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(rin);

		// System.out.println();
		assertEquals(tester.uniques(), 2);
	}

	@Test
	void testOccurances() {
		SuperSackSetObj tester = new SuperSackSetObj();
		String obito = "half";
		String rin = "Through";
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(rin);

		// System.out.println();
		assertEquals(tester.occurencesOf(obito), 5);
		assertEquals(tester.occurencesOf(rin), 3);
		assertEquals(tester.occurencesOf(obito), 5);

	}

	@Test
	void testSize() {
		SuperSackSetObj tester = new SuperSackSetObj();
		String obito = "half";
		String rin = "Through";
		String kakashi = "Live";
		String itachi = "ill";
		String pain = "push";
		String sosori = "puppet";
		tester.addElement(obito);
		tester.addElement(rin);
		tester.addElement(kakashi);
		tester.addElement(itachi);
		tester.addElement(pain);
		tester.addElement(sosori);
		tester.addElement(sosori);
		tester.addElement(sosori);
		tester.addElement(sosori);
		tester.addElement(sosori);
		tester.addElement(sosori);

		// System.out.println("The size is:"+tester.sizeOf());

		assertEquals(tester.sizeOf(), 11);

	}

}
