package cs211;

import java.util.ArrayList;

/*The purpose of this class is to create an ArrayList Object with
/ specific methods we can use to control it
/ @Alex Sandoval 10/3/21
 */

public class SuperSackSetObj implements SuperSackSet {

	private ArrayList<Node> ssso;

	// This constructor will setup the main Array that will be used in all methods
	public SuperSackSetObj() {
		ssso = new ArrayList<Node>();

	}

	/*
	 * This method will tell me how many items are in the ArrayList Linear I think
	 * walking down the ArrayList and looking for matches is a pretty efficient way
	 * to check the size().
	 */
	@Override
	public int sizeOf() {
		Node current; // Node to handle any duplicate items
		int curCount = 0; // This variable will hold the current count of items
		for (int i = 0; i < ssso.size(); i++) { // Goes through the whole list
			current = ssso.get(i); // assigns the node to place holder
			curCount += (current.getCounter() + 1);
			// System.out.println(curCount);
		}
		return curCount;
	}

	/*
	 * This method will tell me how many unique items there are Constant Definitely
	 * the most efficient way to check for unique objects using an ArrayList
	 */
	@Override
	public int uniques() {
		return ssso.size(); // The size only counts unique items
	}

	/*
	 * This method will tell me if the ArrayList is empty or not Constant Also I
	 * think, the most efficient way to check if the ArrayList is empty
	 */
	@Override
	public boolean isEmpty() {
		if (ssso.size() == 0) {
			return true;
		} else {
			return false;
		}

	}

	/*
	 * This method will add a unique element to the arrayList or increase the count
	 * for an element contained Linear This one could definitely be more efficient
	 * if I used a "For each" loop. Technically all of them would be more efficient
	 * that way.
	 */
	@Override
	public void addElement(Object o) {
		Node current; // Node to handle any duplicate items

		for (int i = 0; i < ssso.size(); i++) { // Goes through the whole list
			// System.out.println(ssso.get(i));
			current = ssso.get(i); // assigns duplicates to place holder
			if (o.equals(current.getO())) { // Checks for duplicate instances
				current.incCounter(); // Increase count for the duplicate object
				return;
			}
		}
		Node n = new Node(o); // Creates a new node to hold new objects
		ssso.add(n); // Creates a new entry in the list for new Objects
	}

	/*
	 * This method will remove an object from the Array list Linear This one could
	 * also greatly benefit from a "for each" loop, but otherwise is pretty
	 * efficient
	 */
	@Override
	public void removeElement(Object o) {
		Node current; // Node to handle any duplicate items
		for (int i = 0; i < ssso.size(); i++) { // Goes through the whole list
			current = ssso.get(i); // assigns the node to place holder
			if (current.getO().equals(o)) {
				if (current.getCounter() > 1) {
					current.decCounter();
				} else {
					ssso.remove(i);
				}
			}

		}

		ssso.remove(o);
	}

	/*
	 * This method will search the list for a specified object Linear Using a
	 * "for each" loop would help this one marginally as well, but the way it is
	 * isn't too bad.
	 * 
	 */
	@Override
	public boolean contains(Object o) {
		Node current; // This is a handle for my current node
		for (int i = 0; i < ssso.size(); i++) { // Walks through list
			current = ssso.get(i); // holds current Node in list
			if (o.equals(current.getO())) { // checks Node for a match
				return true; // returns true if matching
			}
		}
		return false; // returns false if no match
	}

	/*
	 * This method will find the occurrences of a particular object in the list
	 * Linear This one is also about as efficient as it can be in these
	 * circumstances.
	 */
	@Override
	public int occurencesOf(Object o) {
		Node current; // This is a handle for my current node
		for (int i = 0; i < ssso.size(); i++) {
			current = ssso.get(i);
			if (o.equals(current.getO())) {
				return current.getCounter() + 1; // This will return the # of instances of that Object
			}
		}
		return 0;
	}

	/*
	 * This method will clear the list constant This one is extremely efficient
	 */
	@Override
	public void clear() {
		ssso.clear();
	}

}
