module CS120.ASandoval {
    requires javafx.controls;
	requires javafx.graphics;
	requires javafx.base;
    exports CS120.ASandoval;
    
//    opens cs120._ASandoval_GUI to javafx.fxml;
//    exports cs120._ASandoval_GUI;
    
}