module CS120.ECASandoval20 {
    requires javafx.controls;
    requires javafx.fxml;

    opens CS120.ECASandoval20 to javafx.fxml;
    exports CS120.ECASandoval20;
}
