import java.util.Scanner;

public class Interrogator {

	//Member Variables 
	private String request;
	private double vReturn;
	Scanner scanny = new Scanner(System.in);
	
	//Constructor
	public Interrogator(String request, double vReturn) {
		this.request = request;
		this.vReturn = vReturn;
	}
	//Most important function executes purpose of object 
	public double infoRet() {
		System.out.println(this.request);
		return scanny.nextDouble();
	}
	
	//getters and setters
	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public double getvReturn() {
		return vReturn;
	}

	public void setvReturn(double vReturn) {
		this.vReturn = vReturn;
	}

}