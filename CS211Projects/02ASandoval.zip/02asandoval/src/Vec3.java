
public class Vec3 {
	/*
	 * This is the vector Object My approach is that I have no idea how to
	 * manipulate vectors stored in data structure
	 */

	// MY MEMBER VARIABLES
	protected double x = 0;
	protected double y = 0;
	protected double z = 0;
	protected static String stringVec = "Cherry";

	public Vec3(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	// Methods
	// This method returns a new vector whose values are derived from the current
	public Vec3 copy() {
		Vec3 copyVector = new Vec3(this.x, this.y, this.z);
		return copyVector;
	}

	// this method adds the other vector to the current vector
	public void plus(Vec3 other) {
		this.x += other.getX();
		this.y += other.getY();
		this.z += other.getZ();
	}

	// this method subtracts the other vector from the current vector
	public void minus(Vec3 other) {
		this.x -= other.getX();
		this.y -= other.getY();
		this.z -= other.getY();
	}

	// this method returns the magnitude (length) of the current vector.
	public double mag() { // Gives the length of a vector in double from (x^2 + y^2 + z^2
		double mag = Math.sqrt(Math.pow(this.x, 2) + Math.pow(this.y, 2) + Math.pow(this.z, 2));
		return mag;
	}

	// this method scales the current vector by the scalar value
	public void scale(double sf) {
		this.x *= sf;
		this.y *= sf;
		this.z *= sf;
	}

	// this method returns a normalized unit vector from the current vector
	public Vec3 unit() {
		Vec3 magVector = new Vec3(this.x, this.y, this.z);
		magVector.x /= mag();
		magVector.y /= mag();
		magVector.z /= mag();
		return magVector;
	}

	// This method returns the dot product (inner project) scalar value
	public double dot(Vec3 other) {
		return (this.x * other.getX()) + (this.y * other.getY()) + (this.z * other.getZ());
	}

	// This method gets the cross product of the current vector and another vector
	public Vec3 cross(Vec3 other) {
		double newVecX = (this.y * other.getZ()) - (this.z * other.getY());
		double newVecY = (this.z * other.getX()) - (this.x * other.getZ());
		double newVecZ = (this.x * other.getY()) - (this.y * other.getX());
		return new Vec3(newVecX, newVecY, newVecZ); // Initializes new vector
	}

	// this method returns a string representation of the current vector
	public String toString() {
		String stringVec1 = ("x=" + this.x + " y=" + this.y + "  z=" + this.z);
		return stringVec1;
	}

	// Setters
	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public void setZ(double z) {
		this.z = z;
	}

	// Getters
	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getZ() {
		return z;
	}
}
