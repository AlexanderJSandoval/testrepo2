import java.util.Scanner;

/* This class is supposed to make vectors, it allows us to enter and manipulate vectors.
* 
* I did not understand this assignment at all at first, but since tutoring has been made available I've put a lot of hours into fixing this and
* making it workable. 
*/
public class main extends Vec3 {

	public main(double x, double y, double z) {
		super(x, y, z);
	}

	public static void main(String[] args) {

		Scanner scanny = new Scanner(System.in); // Creates Scanner Object

		Vec3 s = new Vec3(0, 0, 0); // Creates Vector object

		/*
		 * This sections will collect numbers for the vectors
		 */

		// Prompt users for values
		Interrogator rPoints = new Interrogator("Please give us an amount of points for R^3", 0.00);

		// Make the double fit into the code
		int points = (int) rPoints.infoRet();
		Vec3[] vectors = new Vec3[points]; // Initialize Array for values

		// While loop to create vectors from chosen values
		int counter = 0;
		while (counter < points) {
			// Gather points for vector
			Interrogator findX = new Interrogator("Please enter an x", 0);
			double dx = findX.infoRet();
			Interrogator findY = new Interrogator("Please enter an y", 0);
			double dy = findY.infoRet();
			Interrogator findZ = new Interrogator("Please enter an z", 0);
			double dz = findZ.infoRet();
			// end gathering
			Vec3 newInVec = new Vec3(dx, dy, dz);// Initializes new vectors
			vectors[counter] = newInVec; // Adds Vector to the Array
			System.out.println("Vector Initialized");
			counter++;
		}
		// This while loop assigns "current point", "previous point", and "Next point"
		counter = 0;
		Vec3[] edgeVec = new Vec3[points]; // Initialize Array for edge vectors
		while (counter < vectors.length) {
			// initializing variables
			Vec3 cp = vectors[counter];
			Vec3 pp;
			Vec3 np;
			// Edge case coverage
			if (counter == 0) {
				pp = vectors[vectors.length - 1];
			} else {
				pp = vectors[counter - 1];
			}
			if (counter == points - 1) {
				np = vectors[0];
			} else {
				np = vectors[counter + 1];
			}

			Vec3 e1 = cp.copy();
			e1.minus(pp);
			edgeVec[counter] = e1;

			Vec3 e2 = np.copy();
			e2.minus(cp);
			edgeVec[counter] = e2;

			Vec3 v = e1.cross(e2);
			s.plus(v); // This adds v to s
			s.unit(); // this normalizes s and gives us our final answer
			System.out.println(s);
			counter++;
		}

		scanny.close(); // This Prevents a memory leak
	}

}
