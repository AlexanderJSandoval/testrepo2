import static org.junit.Assert.*;

import org.junit.Test;
import java.util.ArrayList.*
;public class VectorTester {

	
	
	@Test
	public void testRPointsD() {
		Interrogator rPoints = new Interrogator("I'm so tired of this", 0);
		assertTrue(rPoints.getvReturn()== 0);
	}
	
	
}
