/*
 * This class will establish the Employee object and the several piece of data attached to it
 */

public class Employee {

	//This is the list of attributes for the Employee object
	protected String businessTravel;
	protected Integer distanceFromHome;
	protected String educationField;
	protected Integer employeeNumber;
	protected String jobRole;
	protected String maritalStatus;
	protected Double monthlyIncome;
	protected Integer monthlyRate;
	protected Boolean overtime;
	protected Integer stockOptions;
	protected Double totalWorkingYears;
	protected Integer Age;
	protected Boolean gender;

	//This is the contructor setting the attributes of the employee class
	public Employee(String businessTravel, Integer distanceFromHome, String educationField, Integer employeeNumber,
			String jobRole, String maritalStatus, Double monthlyIncome, Integer monthlyRate, Boolean overtime,
			Integer stockOptions, Double totalWorkingYears, Integer age, Boolean gender) {
		super();
		this.businessTravel = businessTravel;
		this.distanceFromHome = distanceFromHome;
		this.educationField = educationField;
		this.employeeNumber = employeeNumber;
		this.jobRole = jobRole;
		this.maritalStatus = maritalStatus;
		this.monthlyIncome = monthlyIncome;
		this.monthlyRate = monthlyRate;
		this.overtime = overtime;
		this.stockOptions = stockOptions;
		this.totalWorkingYears = totalWorkingYears;
		Age = age;
		this.gender = gender;
	}

	//THESE ARE THE AUTO GENEREATED GETTERS AND SETTERS
	public String getBusinessTravel() {
		return businessTravel;
	}
	public void setBusinessTravel(String businessTravel) {
		this.businessTravel = businessTravel;
	}
	public Integer getDistanceFromHome() {
		return distanceFromHome;
	}
	public void setDistanceFromHome(Integer distanceFromHome) {
		this.distanceFromHome = distanceFromHome;
	}
	public String getEducationField() {
		return educationField;
	}
	public void setEducationField(String educationField) {
		this.educationField = educationField;
	}
	public Integer getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(Integer employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getJobRole() {
		return jobRole;
	}
	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public Double getMonthlyIncome() {
		return monthlyIncome;
	}
	public void setMonthlyIncome(Double monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}
	public Integer getMonthlyRate() {
		return monthlyRate;
	}
	public void setMonthlyRate(Integer monthlyRate) {
		this.monthlyRate = monthlyRate;
	}
	public Boolean getOvertime() {
		return overtime;
	}
	public void setOvertime(Boolean overtime) {
		this.overtime = overtime;
	}
	public Integer getStockOptions() {
		return stockOptions;
	}
	public void setStockOptions(Integer stockOptions) {
		this.stockOptions = stockOptions;
	}
	public Double getTotalWorkingYears() {
		return totalWorkingYears;
	}
	public void setTotalWorkingYears(Double totalWorkingYears) {
		this.totalWorkingYears = totalWorkingYears;
	}
	public Integer getAge() {
		return Age;
	}
	public void setAge(Integer age) {
		Age = age;
	}
	public Boolean getGender() {
		return gender;
	}
	public void setGender(Boolean gender) {
		this.gender = gender;
	}




}
