
public class Main {

	//This is the main that will create the tree object, which is the total of the project
	public static void main(String[] args) {
		BdTree tree = new BdTree();



	}

}
