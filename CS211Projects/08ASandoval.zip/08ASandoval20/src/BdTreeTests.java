import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class BdTreeTests {
	public EmployeeIO object;
	public ArrayList<Decisions> dec;
	
	@Test
	void tests() {
		object = new EmployeeIO();	//processes the file
		dec = object.storage; // brings brings in the results of the file
		System.out.println(dec.get(0));
		//assertEquals((dec.get(2)) == ("Feature"));
	}

}
