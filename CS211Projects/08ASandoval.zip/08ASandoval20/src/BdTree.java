import java.util.ArrayList;

public class BdTree {

	//Solo member variable used for the nodes that make up our tree
	public BdNode root;
	public EmployeeIO object;
	public ArrayList<Decisions> dec;
	public Decisions nextDesc;
	public Integer counter =0;
	public String address;

	//Constructor
	public BdTree() { //This constructor does everything, if you want a tree create one and it calls everything else
		super();
		object = new EmployeeIO();	//processes the file
		dec = object.storage; // brings brings in the results of the file
		int i=0;
		while(i !=2) { // I encounter an error if I do anymore than 2 times, this is certainly and error, but if I don't have the while loop it only prints the first node: need more testing
			root = treeBuilder();
			root.dump();
			i++;
		}
	}
	//This method builds the tree and returns the current node
	public BdNode treeBuilder() {
		nextDesc = dec.get(counter);	
		BdNode inNode = new BdNode(nextDesc);
		counter++;
		if (nextDesc.getNode().equals("I")) {
			inNode.left = treeBuilder();
			inNode.right = treeBuilder(); 
		}
			//else {
//		 address = nextDesc.getAddress();
//		 if (address.endsWith("1")) {
//			 inNode.left = treeBuilder();
//		 } else {
//			 inNode.right = treeBuilder(); 
//		 }
//		}
		return inNode;
	}



	/*
	 * public void findNode(Employee e) {
	 * 
	 * }
	 */

	//AUTO GENERATED GETTER AND SETTERS
	public BdNode getRoot() {
		return root;
	}

	public void setRoot(BdNode root) {
		this.root = root;
	}
}
