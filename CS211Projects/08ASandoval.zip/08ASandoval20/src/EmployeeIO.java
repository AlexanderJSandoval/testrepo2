import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;

/*
 * This section of code is responsible for bringing in the information from the
 * file
 */
public class EmployeeIO {
	//These are my member variables
	File employeeRaw;
	FileReader f;
	BufferedReader br = null;
	Integer I;
	public ArrayList<Decisions> storage;
	public Decisions desc;
	public Decisions desc1;
	//This is my employeeIO constructor that brings the file in
	public EmployeeIO(){
		//This calls the method that brings in the file
		employeeFile();
	}

	//Main Method that imports the file
	public void employeeFile(){
		File employeeRaw = new File("./EmployeeStuff.csv");  //This specifies where the file is located in the project

		storage = new ArrayList<Decisions>(); //This assigns the main ArrayList that will hold the information we need 
		try {
			//Established FileReader and BufferedReader
			f = new FileReader(employeeRaw);
			br = new BufferedReader(f);

			String line = br.readLine();
			while (line !=null) { //While loop to bring in info

				String[]csv;
				csv = line.split(","); //Line splits on Comma, could have to do with the ",,," I keep getting in the console
				if (csv[5].equals("Numeric")){ //Specified in the CSV file
					desc = new Decisions(Integer.getInteger(csv[0]), csv[1] , Integer.getInteger(csv[2]), csv[3], csv[4],csv[5], (csv[6]), Boolean.getBoolean(csv[7]));

					storage.add(desc); // ADDS to storage
				} else {
					desc1 = new Decisions(Integer.getInteger(csv[0]), csv[1] , Integer.getInteger(csv[2]), csv[3], csv[4], csv[5],(csv[6]), Boolean.getBoolean(csv[7]));

					storage.add(desc1);// ADDS to storage
				} 
				line = br.readLine();

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
