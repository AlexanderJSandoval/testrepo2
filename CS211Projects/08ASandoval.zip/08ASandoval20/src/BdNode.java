
public class BdNode {

	public BdNode left;
	public BdNode right;
	protected Decisions decision;

	//Constructor
	public BdNode(Decisions decision) {
		super();
		this.decision=decision;
	}	

	public void dump() {
		dumpR(5);
	}

	private void dumpR(int depth) {
		int adjDepth= (depth*5);
		for(int i=0;i<adjDepth;i++) {
			System.out.print(" ");
		}
		System.out.println(this);
		if (this.decision.node.equals("I")) {
			this.left.dumpR(depth+1);
			this.right.dumpR(depth+1);
		}
	}

	//Getters and Setters
	public BdNode getLeft() {
		return left;
	}

	public void setLeft(BdNode left) {
		this.left = left;
	}

	public BdNode getRight() {
		return right;
	}

	public void setRight(BdNode right) {
		this.right = right;
	}

	@Override
	public String toString() {
		return decision.toString();
	}


}
