
public class Decisions {

	protected Integer id;
	protected String address;
	protected Integer parentID;
	protected String node;
	protected String feature;
	protected String type;
	protected String value;
	protected Boolean classification;

	//Contractor 
	public Decisions(Integer id, String address, Integer parentID, String node, String feature, String type, String value,
			Boolean classification) {
		super();
		this.id = id;
		this.address = address;
		this.parentID = parentID;
		this.node = node;
		this.feature = feature;
		this.type = type;
		this.value = value;
		this.classification = classification;
	}

	//Setters and getters
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getParentID() {
		return parentID;
	}

	public void setParentID(Integer parentID) {
		this.parentID = parentID;
	}

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}

	public String getFeature() {
		return feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Boolean getClassification() {
		return classification;
	}

	public void setClassification(Boolean classification) {
		this.classification = classification;
	}
	//To STRING
	@Override
	public String toString() {
		return feature;
	}

}
