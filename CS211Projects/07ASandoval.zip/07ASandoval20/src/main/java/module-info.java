module CS120.ASandoval20 {
    requires javafx.controls;
    requires javafx.fxml;

    opens CS120.ASandoval20 to javafx.fxml;
    exports CS120.ASandoval20;
}
