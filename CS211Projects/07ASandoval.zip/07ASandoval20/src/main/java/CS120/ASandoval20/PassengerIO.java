package CS120.ASandoval20;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class PassengerIO {

	protected passengers passengerFromString(String line) {
		
		String[] parts = line.trim().split("[|]");
		
		Double age = Double.parseDouble(parts[0]);
		String cabin = parts[1].trim();
		String embark = parts[2].trim();
		Double fare = Double.parseDouble(parts[3]);
		String name = parts[4].trim();
		Integer parch = Integer.parseInt(parts[5]);
		Integer passID = Integer.parseInt(parts[6]);
		Integer PClass = Integer.parseInt(parts[7]);
		String sex = parts[8].trim();
		Double sibSp = Double.parseDouble(parts[9]);
		Double survived = Double.parseDouble(parts[10]);
		Double ticketnum = Double.parseDouble(parts[11]);
		String title = parts[12].trim();
		Integer familySize = Integer.parseInt(parts[7]);
		return null;
		
		//return new passengers()
	}

}
