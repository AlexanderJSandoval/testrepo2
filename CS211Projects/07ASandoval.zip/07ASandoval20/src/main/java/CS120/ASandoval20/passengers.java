package CS120.ASandoval20;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/*
 * This class establishes the passenger object
 * This object will hold onto the data for a single passenger from the titanic doc
 */

public class passengers {

	double age;
	String cabin;
	String embark;
	double fare;
	String name;
	int parch;
	int passID;
	int pClass;
	String sex;
	double sibSp;
	double survived;
	double ticketnum;
	String title;
	int familySize;

	public passengers(String[] info) {

		// These statements will input the info and throw exceptions if the information
		// can't be taken
		try {
			// Block of code to try
			age = Double.valueOf(info[0]);
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of data AGE could not be computed");
			// Right now all it does is make a note that the data could not be brought in
		}
		try {
			// Block of code to try
			cabin = info[1];
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of CABIN data could not be computed");
		}
		try {
			// Block of code to try
			embark = info[2];
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of EMBARK data could not be computed");
		}
		try {
			// Block of code to try
			fare = Double.valueOf(info[3]);
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of FARE data could not be computed");
		}
		try {
			// Block of code to try
			name = info[4];
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of NAME data could not be computed");
		}
		try {
			// Block of code to try
			parch = Integer.valueOf(info[5]);
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of PARCH data could not be computed");
		}
		try {
			// Block of code to try
			passID = Integer.valueOf(info[6]);
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of PASSID data could not be computed");
		}
		try {
			// Block of code to try
			pClass = Integer.valueOf(info[7]);
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of data PCCLASS could not be computed");
		}
		try {
			// Block of code to try
			sex = info[8];
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of SEX data could not be computed");
		}
		try {
			// Block of code to try
			sibSp = Double.valueOf(info[9]);
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of SIBSP data could not be computed");
		}
		try {
			// Block of code to try
			survived = Double.valueOf(info[10]);
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of SURVIVED data could not be computed");
		}
		try {
			// Block of code to try
			ticketnum = Double.valueOf(info[11]);
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of TICKETNUM data could not be computed");
		}
		try {
			// Block of code to try
			title = info[12];
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of TITLE data could not be computed");
		}
		try {
			// Block of code to try
			familySize = Integer.valueOf(info[13]);
		} catch (Exception e) {
			// Block of code to handle errors
			System.out.println("A piece of FAMILY SIZE data could not be computed");
		}
	}

//////////THESE ARE THE AUTO GETTER AND SETTERS
	public double getAge() {
		return age;
	}

	public void setAge(double age) {
		this.age = age;
	}

	public String getCabin() {
		return cabin;
	}

	public void setCabin(String cabin) {
		this.cabin = cabin;
	}

	public String getEmbark() {
		return embark;
	}

	public void setEmbark(String embark) {
		this.embark = embark;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getParch() {
		return parch;
	}

	public void setParch(int parch) {
		this.parch = parch;
	}

	public int getPassID() {
		return passID;
	}

	public void setPassID(int passID) {
		this.passID = passID;
	}

	public int getpClass() {
		return pClass;
	}

	public void setpClass(int pClass) {
		this.pClass = pClass;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public double getSibSp() {
		return sibSp;
	}

	public void setSibSp(double sibSp) {
		this.sibSp = sibSp;
	}

	public double getSurvived() {
		return survived;
	}

	public void setSurvived(double survived) {
		this.survived = survived;
	}

	public double getTicketnum() {
		return ticketnum;
	}

	public void setTicketnum(double ticketnum) {
		this.ticketnum = ticketnum;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getFamilySize() {
		return familySize;
	}

	public void setFamilySize(int familySize) {
		this.familySize = familySize;
	}

}