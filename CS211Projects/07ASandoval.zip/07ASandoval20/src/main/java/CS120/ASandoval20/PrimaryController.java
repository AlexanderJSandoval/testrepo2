package CS120.ASandoval20;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

public class PrimaryController implements Initializable {

	@FXML
	private Button updateBtn;
	@FXML
	private Button editBtn;
	@FXML
	private ListView<passengers> listViewOne;
	@FXML
	private ListView<String> listViewTwo;
	@FXML
	private ListView<String> listViewThree;
	ArrayList<String> names;

	@FXML
	private void switchToSecondary() throws IOException {
		App.setRoot("secondary");
	}

	public void initialize(URL location, ResourceBundle resources) { 
		
		ArrayList<passengers> pass;

		pass = App.application.pList;

		for (int i = 0; i < pass.size(); i++) {

			names.add(pass.get(i).getName());
		}
		// Set list view items here
	}

}
