package CS120.ASandoval20;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * JavaFX App
 */
public class App extends Application {

	private static Scene scene;

	public static App application = new App();

	public static ArrayList<passengers> pList; // This list will keep track of each passenger as their info is passed in

	@Override
	public void start(Stage stage) throws IOException {
		scene = new Scene(loadFXML("primary"), 640, 480);
		stage.setScene(scene);
		// scene.getStylesheets().add("primaryStyle.css");
		stage.show();
	}

	static void setRoot(String fxml) throws IOException {
		scene.setRoot(loadFXML(fxml));
	}

	private static Parent loadFXML(String fxml) throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
		return fxmlLoader.load();
	}

	// This should bring the raw data in into App.java
	public static void dataIntake() {
		File titanicRaw = Paths.get("titanic.txt").toFile();

		/*
		 * This section of code is responsible for bringing in the information from the
		 * file
		 */
		BufferedReader br = null;
		{
			try {

				System.out.println(titanicRaw.toString()); // This will turn the raw data into a string

				FileReader fr = new FileReader(titanicRaw);

				br = new BufferedReader(fr);

				String curLine = br.readLine();
				curLine = br.readLine();

				pList = new ArrayList<passengers>();

				while (curLine != null) {
					// process data in str
					//System.out.println(curLine);

					String[] passengerInfo = curLine.split("\\|"); // start reading the next line
					// the "\\|" is needed to be able to read the | that separates the data
					// This whole "\\|" took me forever and like 3 tutoring sessions to figure out

					// System.out.println(Arrays.toString(passengerInfo)); //For testing purposes

					System.exit(-1);
					passengers higgs; // This is my holder for passenger info while it's happening

					higgs = new passengers(passengerInfo); // Whichever line is currently being held
					curLine = br.readLine();

					pList.add(higgs); // This adds the current one to the list

				}

			} catch (IOException ex) {
				// Handle exception here
				System.err.println(": thats gonna be a problem cheif");
			} finally { // close file here
				try {
					if (br != null) {
						br.close();
					}
				} catch (Exception ex1) {
					ex1.printStackTrace(); // give up
					System.exit(-1);
				}
			}

		}
	}

	public static void main(String[] args) {
		dataIntake(); // Brings in the titanic file and data
		launch(); // Launches App, currently non-functioning

	}

}