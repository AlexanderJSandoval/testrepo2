import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Segment extends Rectangle {
	/*
	 * This class will create the segment object that is vital to the snake object
	 * The Snake will be made of a variety of segments These segments will be
	 * circles that our snake class will organize in a link list
	 * 
	 */
	protected int x;
	protected int y;
	protected int w;
	protected int h;

	protected Segment next;

	// This is the segment constructor
	public Segment(int x, int y, int w, int h) {
		super(); // this brings in parts of Rectangle
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		next = null; // This sets the next segment to null for now
	}

	/*
	 * This is the basic method that allows for segments to move in a particular
	 * direction It is different than moveSegments() that we see in snake
	 * 
	 * Instead of teleporting the segments it allows for the segment to move
	 * gradually in a selected direction
	 * 
	 * nx and ny will not be the desired destination (like in moveSegments()), but
	 * rather a combination of positive or negative numbers to determine direction,
	 * and the number itself reflecting the speed (numbers farther from 0 being
	 * faster while numbers close to 0 will move slower)
	 * 
	 * Ideally we will call this method within a while loop in a class designed to
	 * move the snake
	 * 
	 */
	public void moveSegment(int nx, int ny) {
		this.x += nx; // the "+=" is the thing that makes this method so different
		this.y += ny; // Instead of instantly changing the variables we slowly change them
	}

	// This is the basis for most of the drawing of snakes that will happen in this
	// project
	protected void paint(Graphics g) {
		g.setColor(Color.black);
		g.drawRect(this.x, this.y, this.w, this.h);
	}

	/*
	 * This is a getter for next It will return the next segment, which means
	 * 
	 * nothing in this method but becomes very important in the snake class for link
	 * list purposes
	 */
	public Segment getNext() {
		return next;
	}

	/*
	 * This is a setter for next It will return the next segment, which means
	 * 
	 * nothing in this method but becomes very important in the snake class for link
	 * list purposes
	 */
	public void setNext(Segment next) {
		this.next = next;
	}

}
