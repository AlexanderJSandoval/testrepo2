import static org.junit.Assert.*;

import org.junit.Test;

public class testSnakeClass {

	@Test
	public void testDirection() {
		Snake testSnake = new Snake(200, 200, 50, 50, 2); // Establish test object
		testSnake.setDirection(1, 1); // This runs the method I want to test
		assertTrue((testSnake.x == 201 && testSnake.y == 201));// This checks for updated variables
	}

	@Test
	public void testDirection2() {
		Snake testSnake = new Snake(200, 200, 50, 50, 2); // Establish test object
		testSnake.setDirection(-1, -1); // This runs the method I want to test
		assertTrue((testSnake.x == 199 && testSnake.y == 199));// This checks for updated variables
	}
	@Test
	public void testMoveHead1() {
		Snake testSnake = new Snake(200, 200, 50, 50, 2); // Establish test object
		testSnake.moveHead(); // This runs the method I want to test
		assertTrue((testSnake.x == 199 && testSnake.y == 199));// This checks for updated variables
	}
	
}
