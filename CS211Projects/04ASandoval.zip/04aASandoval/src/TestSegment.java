import static org.junit.Assert.*;

import org.junit.Test;

public class TestSegment {

	@Test
	public void testSeg0() {
		Segment segTest = new Segment(10, 11, 12, 13);

		assertTrue(segTest.x == 10);
		assertTrue(segTest.y == 11);
		assertTrue(segTest.w == 12);
		assertTrue(segTest.h == 13);
	}

	public void testmoveSeg() {
		Segment moveSegTest = new Segment(10, 11, 12, 13);
		moveSegTest.moveSegment(205, 270);

		assertTrue(moveSegTest.x == 250);
		assertTrue(moveSegTest.x == 270);
	}

	public void testgetNext() {
		Segment segTest = new Segment(10, 11, 12, 13);
		segTest.setNext(segTest);
		System.out.println(segTest);
		assertTrue(segTest.getNext() == segTest);
	}

}
