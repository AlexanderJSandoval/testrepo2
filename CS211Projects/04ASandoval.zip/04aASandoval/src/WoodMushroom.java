
public class WoodMushroom extends Mushroom {

	public WoodMushroom(int x, int y, int w, int h) {
		super(x, y, w, h);
	}

	@Override
	public void whenConsumed() {

	}

}
