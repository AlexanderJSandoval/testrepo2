
public class BadMushroom extends Mushroom {

	public BadMushroom(int x, int y, int w, int h) {
		super(x, y, w, h);
	}

	@Override
	public void whenConsumed() {

	}
}