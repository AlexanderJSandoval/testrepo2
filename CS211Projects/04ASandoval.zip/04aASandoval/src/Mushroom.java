import java.awt.Rectangle;

public abstract class Mushroom extends Rectangle {
	/*
	 * This class will sever as the basis for the mushrooms that will be in the
	 * games This class will establish the constructor and whenConsumed() method
	 */

	// These member variables will be sent to all classes using built off this
	// abstract class
	protected int x;
	protected int y;
	protected int w;
	protected int h;

	// This constructor will server to create the mushroom itself
	public Mushroom(int x, int y, int w, int h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;

	}

	public abstract void whenConsumed();

	// START SETTERS AND GETTERS

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getW() { // W
		return w;
	}

	public void setW(int w) {
		this.w = w;
	}

	public int getH() { // H
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}
	// END SETTERS AND GETTERS
}
