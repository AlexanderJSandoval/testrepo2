import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
/*This is the main object within the project
 * It will create a snake out of segments
 * The Snake will use tailFirst and tailLast in order to control the link list of segments that will make up the snake
 * 
 */

//RECTANGLE CLASS HAS AN INTERSECT METHOD FOR COLLISION DETECTION
public class Snake extends Rectangle {

	protected int x;
	protected int y;
	protected int dx; // "d" before any variable in this project severs to designate it as the future
						// variable in a transition or movement
	protected int dy;
	protected int w ; //I'm using a set size for the ovals for now
	protected int h ;

	protected Segment tailFirst; // These two variables are absolutely needed for us to manipulate our link list of segments
	protected Segment tailLast;
	protected int ignoreCounter; // This variable exists almost solely for setIgnoreCounter(), which will be important for one of the mushroom classes

	//This is the constructor for the Snake object. For now "n" is for number of segments
	public Snake(int x, int y, int w, int h, int n) {
		int i = 0;
		while (i < n) {
			Segment segOne = new Segment(x, y, w, h); // shift x&y so no stacking (number of segments made)
			if (i == 0) { 					//This way the first one created is both the first and last in the list
				tailFirst = segOne;
				tailLast = segOne;
			} else { 						//Otherwise it automatically becomes the last in the list
				tailLast.setNext(segOne);
				tailLast = segOne;
			} 
			i++; //To prevent infanite loop
		}
	}
	//This method will set the direction of the snake's movement
	public void setDirection(int x, int y) {
		this.dx += x;
		this.dy += y;
	}
	//This will set the first segment to move
	public void moveHead() {
		tailFirst.moveSegment(dx, dy);
		moveSegments();
	}
	// This will move all segments
	private void moveSegments() {
		Segment cSeg = tailFirst.getNext(); //cSeg is the variable we use to store the current segment which allows us to move down the list
		while (cSeg != null) { //Running this to null is how I find the end of the list
			cSeg.moveSegment(dx, dy); //now that the segment has been selected we just move it to the specified coordiantes 
			cSeg = cSeg.getNext();  //This actually sends it to the next segment 
		}
	}
	//This method will check to see if the snakes head is colliding with any of the other segment
	public boolean isCollidingwithTail() {
		Segment cSeg = tailFirst.getNext(); //This cSeg is unrelated to the other one, though it does still serve to hold whatever segment we are working with
		while (cSeg != null) { //Running this to null is how I find the end of the list
			if (tailFirst.intersects(cSeg)) { //This will check if tailFirst intersects with cSeg(Which represents whatever segment is being stored there)
				return true;
			}
		}
		return false;
	}
	//This method will draw the snake on the Canvas
	public void drawSnake(Graphics g) {
		Segment cSeg = tailFirst.getNext(); //This cSeg is unrelated to the other one, though it does still serve to hold whatever segment we are working with
		while (cSeg != null) {	//This while loop will draw each segment in the link list
			g.setColor(Color.green);		//Sets snake color to green
			cSeg.paint(g);// This section will actually draw the oval that represents the segment
			cSeg = cSeg.getNext();
		}
	}
	
	public void setIgnoreCounter(int i) {
		ignoreCounter = i;
	}
	// This method will increase the snakes size by one segment
	public void grow() {
		Segment newSeg = new Segment(((w * dx) + x), ((h * dy) + y), w, h); //The new segment is temporarily stored in newSEg
		tailLast.setNext(newSeg); //these next two lines add newSeg into the link list  
		tailLast = newSeg;
	}
}
