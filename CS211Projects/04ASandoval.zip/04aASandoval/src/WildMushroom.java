
public class WildMushroom extends Mushroom {

	public WildMushroom(int x, int y, int w, int h) {
		super(x, y, w, h);
	}

	@Override
	public void whenConsumed() {

	}

}
