import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
/*
 *This class will serve as my main for Lab04 
 *This Class will also establish and setup the frame that the game will be played on and all the objects will be drawn on.
 *
 *
 */
public class Starter {

	private Canvas theCanvas;

	public static void main(String[] args) {

		JFrame MainFrame = new JFrame("Le Frame");
		MainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MainFrame.setSize(new Dimension(1000, 1000));
		MainFrame.setVisible(true);
//		System.out.println("1s");
		
		Canvas FirstDrawPanel = new Canvas();
		FirstDrawPanel.setPreferredSize(new Dimension(1000, 1000));
//		FirstDrawPanel.setBackground(Color.gray);
//		System.out.println("2s");
		
//		gameController gme = new gameController(FirstDrawPanel);
//		System.out.println("3s");
		
		MainFrame.add(FirstDrawPanel);
		MainFrame.pack();
		MainFrame.repaint();
//		System.out.println("4s");
	
		
	}

}
