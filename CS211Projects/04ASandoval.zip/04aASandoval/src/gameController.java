import java.util.ArrayList;
import java.util.Random;

import javax.swing.Timer;

public class gameController {
	/*
	 * The GameController file will basically be the "game" When a new game is
	 * started it will be an instance of GameController being created It will us
	 * methods to manage the snake as well as the game It does things like kill the
	 * snake or reset the snake It will also randomly place Mushrooms throughout the
	 * canvas There are also getters and setters for most of the variables
	 */

	protected Canvas canvo;
	protected int points;
	protected int lives;
	protected Snake ka;
	protected ArrayList<Mushroom> shrooms;
	protected Random rando;

	/*
	 * This is my constructor It will create an new Canvas Object and for all
	 * intensive purposes initialize an instance of the game It will create a new
	 * window in eclipse and run the instance on that canvas
	 */
	public gameController(Canvas canvo) {
		this.canvo = canvo; // This establishes the Canvas class for this game
		setLives(2); // This sets the amount of lives to start at 2
		setPoints(0); // This starts the amount of points at zero to be raised during game play
		ka = new Snake(500, 500, 15, 15, 2); // This is our snake object for this instance of the game
		shrooms = new ArrayList<>(); // This is the list of mushrooms to be accessed during the game
		rando = new Random(); // This random object will allow us to generate random numbers
	}

	// This Method will change the snakes direction based on the input
	// This method will be called by onKey() in Canvas to change the snakes
	// direction after processing user input
	public void turnSnake(int direction) {// Direction will be filled in onKey()
		// Currently covers 4 direction
		if (direction == 1) { // UP
			ka.setDirection(0, 1);// Calls the method() in our Snake class
		}
		if (direction == 2) {// RIGHT
			ka.setDirection(1, 0);
		}
		if (direction == 3) {// DOWN
			ka.setDirection(0, -1);
		}
		if (direction == 4) {// LEFT
			ka.setDirection(-1, 0);
		} // No else needed since it will be filled in in another function with no user
			// input
	}// no else because of a layer of abstraction

	// This method serves to move the head and check if the game has ended for any
	// reason
	public void updateWorld() {
		ka.moveHead();
		// To check if the snake has collided with itself
		if (isGameOver() == true) { // This checks to see if the game is over for any reason
			killSnake(); // If so, it adjusts accordingly
			System.out.println("You lose, please honor the game by quiting :)");
		}

	}

	// This method will check to see if the snake is out of bounds
	private boolean isSnakeOffWorld() {// It is a boolean and will return true or false
		if (ka.x > 1000 || ka.y > 1000) { // 1000 is the current size of the game canvas
			return true;// If it is out of bounds
		} else {// It either is or isn't
			return false;// If it is not
		}
	}

	// This method serves to be called if a method of losing the game returns true
	public boolean isGameOver() {
		return (isSnakeOffWorld() == true || ka.isCollidingwithTail() == true);
	} // I'm very proud of myself for writing this in one line :)

	// This method will make new mushrooms at random locations
	public void tryToPlantMushrooms() {// This method uses checkMushroomCollision()
		int mushSelect = rando.nextInt(4); // This will select a specific mushroom
		int mushX = rando.nextInt(1000); // This will create a random x variable and store it
		int mushY = rando.nextInt(1000); // This will create a random y variable and store it
		/*
		 * This section of code will use the random coordinates to create the type of
		 * mushrooms specified by int mushSelect
		 */
		if (mushSelect == 0) {
			WildMushroom wildMush = new WildMushroom(mushX, mushY, 15, 15); // Creates mushroom
			if (checkMushroomCollision(wildMush) == true) { // Checks for collision
				shrooms.add(wildMush);// if it passes, it's added to the array
			}
		}
		if (mushSelect == 1) {
			WoodMushroom woodMush = new WoodMushroom(mushX, mushY, 15, 15);// Creates mushroom
			if (checkMushroomCollision(woodMush) == true) {// Checks for collision
				shrooms.add(woodMush);// if it passes, it's added to the array
			}
		}
		if (mushSelect == 2) {
			BadMushroom badMush = new BadMushroom(mushX, mushY, 15, 15);// Creates mushroom
			if (checkMushroomCollision(badMush) == true) {// Checks for collision
				shrooms.add(badMush);// if it passes, it's added to the array
			}
		}
		if (mushSelect == 3) {
			GoodMushroom goodMush = new GoodMushroom(mushX, mushY, 15, 15);// Creates mushroom
			if (checkMushroomCollision(goodMush) == true) {// Checks for collision
				shrooms.add(goodMush);// if it passes, it's added to the array
			}
		}
	}

	// This method will check to see if a new mushroom would collide with an
	// existing one
	private boolean checkMushroomCollision(Mushroom mushy) {
		// This for loop will go through the mushroom arrayList to check all for
		// collisions
		for (int i = 0; i < shrooms.size(); i++) {
			if (shrooms.get(i).intersects(mushy)) {
				return true;
			}
		}
		return false;
	}

	// THis will allows the speed to go up
	public void increaseUpdateSpeed() {
		Timer timey = canvo.getUpTimer(); // creates a timer to store the real timer
		timey.setDelay((int) (timey.getDelay() * .9)); // This adjusts the delay slightly
	}

	// This method will call the the grow function from the snake class
	public void growSnake() {
		ka.grow();
	}

	// This will be called if the snake does something to warrant losing a life
	public void killSnake() {
		resetSnake(); // This will reset the snake
		lives--; // This will reduce the amount of lives accordingly
	}

	// This will reset the snake
	public void resetSnake() {
		ka = new Snake(500, 500, 15, 15, 2); // creates a new snake
	}

	// I don't know what this is supposed to do or be used for. This is my best
	// guess
	private void nextLevel() { // Unsure purpose
		canvo = new Canvas(); // Creates a new canvas
		shrooms = new ArrayList<>(); // creates a new set of mushrooms
	}

	// GETTERS AND SETTERS
	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	public int getLives() {
		return lives;
	}

	public void setLives(int lives) {
		this.lives = lives;
	}

	public Snake getKa() {
		return ka;
	}

	public void setKa(Snake ka) {
		this.ka = ka;
	}

	public ArrayList<Mushroom> getShrooms() {
		return shrooms;
	}

	public void setShrooms(ArrayList<Mushroom> shrooms) {
		this.shrooms = shrooms;
	}

}
