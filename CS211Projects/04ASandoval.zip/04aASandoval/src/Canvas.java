import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JPanel;

/*
 * This class will establish the Canvas object
 * The canvas object will use a variety of timers (animTimer, updateTimer, Mushroom Timer) to repaint the canvas and update the graphics
 * It uses methods like Paint()
 * 
 */
////REMEMBER TO CALL REPAINT NOT PAINT (repaint will work with swing)
public class Canvas extends JPanel implements KeyListener {

	private Timer animTimer;
	private Timer updateTimer;
	private Timer mushroomTimer;
	private boolean firstTime = true;
	private gameController game;

	public Canvas() {
		// super();
		game = new gameController(this);
		animTimer = new Timer(200, new onAnimTimerTick());
		updateTimer = new Timer(200, new onUpdateTimerTick());
		mushroomTimer = new Timer(200, new onMushroomTimerTick());
		this.setFocusable(true);
		this.requestFocus();
		this.addKeyListener(new keyBoardLes());
		repaint();
	}

	public void paint(Graphics g) {// lines, shapes
		super.paint(g);
		game.ka.drawSnake(g);
		if (firstTime) {
			firstTime = false;
		}

	
	}
	public void onKey(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_A) {
			System.out.println("left");
			game.turnSnake(4);
			game.ka.moveHead();
		} else if (e.getKeyCode() == KeyEvent.VK_D) {
			System.out.println("right");
			game.turnSnake(2);
		} else if (e.getKeyCode() == KeyEvent.VK_W) {
			System.out.println("up");
			game.turnSnake(1);
		} else if (e.getKeyCode() == KeyEvent.VK_S) {
			System.out.println("down");
			game.turnSnake(3);
		} 

	}

	private class keyBoardLes implements KeyListener {

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyPressed(KeyEvent e) {
			System.out.println("Key Pressed");
			onKey(e);
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	private class onAnimTimerTick implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			repaint();
		}
	}

	private class onUpdateTimerTick implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			game.updateWorld();
		}
	}

	private class onMushroomTimerTick implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			game.tryToPlantMushrooms();
		}
	}

	public Timer getUpTimer() {
		return updateTimer;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		System.out.println("Key typed");
	}

	@Override
	public void keyPressed(KeyEvent e) {
		System.out.println("Key Pressed");
		onKey(e);
	}

	@Override
	public void keyReleased(KeyEvent e) {
	}
}
